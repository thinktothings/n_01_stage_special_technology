package com.opensources.project.gjp.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.opensources.project.gjp.domain.Sort;

public class SortDaoTest {
	
	SortDao sortDao = null;
	
	@Before
	public void setUp() throws Exception {
		sortDao = new SortDao();
	}

	@Test
	public void testAddSort() {
		Sort sort = new Sort(1,"买牙膏","支出","买高洁士牙膏");
		sortDao.addSort(sort);
	}
	
	@Test
	public void testQuerySortAll() {
		List<Sort> list = sortDao.querySortAll();
		System.out.println(list);		
	}
	
	@Test
	public void testEditSort() {
		Sort sort = new Sort(5,"买牙膏1","支出1","买高洁士牙膏1");
		sortDao.editSort(sort);
	}
	
	@Test
	public void testDeleteSort() {
		Sort sort = new Sort(5,"买牙膏1","支出1","买高洁士牙膏1");
		sortDao.deleteSort(sort);
	}
	
	
	
	

}
